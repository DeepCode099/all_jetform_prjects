package com.adjecti.recruitment.tracker.enumerator;

public enum VacancyStatus {
	VACANT,
	FILLED,
	SUSPENDED,
	CANCELED;

}
