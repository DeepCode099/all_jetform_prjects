package com.adjecti.recruitment.tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecruitmentTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecruitmentTrackerApplication.class, args);
	}

}
