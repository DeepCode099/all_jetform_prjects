package com.adjecti.invoice.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adjecti.invoice.model.InvoiceItem;
import com.adjecti.invoice.repository.InvoiceItemRepository;
import com.adjecti.invoice.service.InvoiceItemService;
@Service
public class InvoiceItemServiceImpl implements InvoiceItemService {

	@Autowired
	private InvoiceItemRepository invoiceItemRepository;
	
	@Override
	public InvoiceItem create(InvoiceItem invoiceItem) {
		return invoiceItemRepository.save(invoiceItem);
	}

}
