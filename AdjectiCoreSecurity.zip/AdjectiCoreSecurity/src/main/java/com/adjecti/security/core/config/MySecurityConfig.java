package com.adjecti.security.core.config;

public class MySecurityConfig {

}
