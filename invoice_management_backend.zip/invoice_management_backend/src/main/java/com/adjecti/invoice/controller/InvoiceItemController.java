package com.adjecti.invoice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adjecti.invoice.model.InvoiceItem;
import com.adjecti.invoice.service.InvoiceItemService;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/invoiceItem")
public class InvoiceItemController {
	
	@Autowired
	private InvoiceItemService invoiceItemService;
	
	@PostMapping
	public ResponseEntity<InvoiceItem> add(@RequestBody InvoiceItem invoiceItem) {
		System.out.println("inoive item save");
		return new ResponseEntity<InvoiceItem>(invoiceItemService.create(invoiceItem), HttpStatus.CREATED);

	}

	

}
