package com.adjecti.recruitment.tracker.enumerator;

public enum HiringStatus {
	
	HIRED,
	NONHIRED,
	INPROCESS,
	CANDIDATEREFUSAL;

}
