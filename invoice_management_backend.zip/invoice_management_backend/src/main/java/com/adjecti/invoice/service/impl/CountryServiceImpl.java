package com.adjecti.invoice.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.adjecti.invoice.model.Country;
import com.adjecti.invoice.service.CountryService;

@Service
public class CountryServiceImpl implements CountryService {

	@Override
	public List<Country> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
