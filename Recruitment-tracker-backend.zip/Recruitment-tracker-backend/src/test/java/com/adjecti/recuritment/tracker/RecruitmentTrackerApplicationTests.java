package com.adjecti.recuritment.tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecruitmentTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
