package com.adjecti.recruitment.tracker.enumerator;

public enum HiringChannel {
	
	INTERNAL,
	EXTERNAL,
	INTERNALANDEXTERNAL;

}
