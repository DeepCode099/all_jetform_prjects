package com.adjecti.invoice.service;

import com.adjecti.invoice.model.InvoiceItem;

public interface InvoiceItemService {

	public InvoiceItem create(InvoiceItem invoiceItem);
}
