package com.adjecti.document.manager.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adjecti.document.manager.model.DMFileType;

public interface DMFileTypeRepository extends JpaRepository<DMFileType, Long> {
	

	
}
