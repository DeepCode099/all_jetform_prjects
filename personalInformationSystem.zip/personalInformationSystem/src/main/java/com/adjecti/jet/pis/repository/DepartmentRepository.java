package com.adjecti.jet.pis.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adjecti.jet.pis.model.Department;


public interface DepartmentRepository extends JpaRepository<Department,Long>{

}
