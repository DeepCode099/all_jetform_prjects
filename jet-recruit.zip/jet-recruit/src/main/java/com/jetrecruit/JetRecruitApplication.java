package com.jetrecruit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JetRecruitApplication {

	public static void main(String[] args) {
		SpringApplication.run(JetRecruitApplication.class, args);
	}

}
