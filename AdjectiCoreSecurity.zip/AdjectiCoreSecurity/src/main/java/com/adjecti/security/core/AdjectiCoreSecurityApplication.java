package com.adjecti.security.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdjectiCoreSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdjectiCoreSecurityApplication.class, args);
	}

}
