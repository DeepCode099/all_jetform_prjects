package com.jetrecruit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JetRecruitApplicationTests {

	@Test
	void contextLoads() {
	}

}
