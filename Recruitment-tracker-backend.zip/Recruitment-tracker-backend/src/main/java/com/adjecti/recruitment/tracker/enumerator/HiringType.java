package com.adjecti.recruitment.tracker.enumerator;

public enum HiringType {
	
	PERMANENT,
	CONTRACTUAL;

}
