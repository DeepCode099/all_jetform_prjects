package com.adjecti.jet.pis.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.adjecti.jet.pis.model.Designation;


@Repository
public interface DesignationRepository extends JpaRepository<Designation,Long> {

}
