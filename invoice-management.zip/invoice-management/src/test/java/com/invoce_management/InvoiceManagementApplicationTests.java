package com.invoce_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoiceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
