package com.adjecti.document.manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentManagerFrontendApplicationTests {

	@Test
	void contextLoads() {
	}

}
