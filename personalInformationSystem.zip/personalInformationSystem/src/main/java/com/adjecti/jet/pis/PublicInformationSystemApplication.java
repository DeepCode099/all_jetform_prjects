package com.adjecti.jet.pis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PublicInformationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PublicInformationSystemApplication.class, args);
	}

}
