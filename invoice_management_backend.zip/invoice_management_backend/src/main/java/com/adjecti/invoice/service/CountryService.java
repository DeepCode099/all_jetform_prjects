package com.adjecti.invoice.service;

import java.util.List;

import com.adjecti.invoice.model.Country;

public interface CountryService {

	public List<Country> getAll();
	
}
